SET IDENTITY_INSERT [dbo].[GameRegions] ON
INSERT INTO [dbo].[GameRegions] ([GameRegionId], [GameRegionName]) VALUES (1, N'NTSC')
INSERT INTO [dbo].[GameRegions] ([GameRegionId], [GameRegionName]) VALUES (2, N'PAL')
INSERT INTO [dbo].[GameRegions] ([GameRegionId], [GameRegionName]) VALUES (3, N'JP')
SET IDENTITY_INSERT [dbo].[GameRegions] OFF
