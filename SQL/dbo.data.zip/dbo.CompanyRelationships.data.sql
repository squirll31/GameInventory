SET IDENTITY_INSERT [dbo].[CompanyRelationships] ON
INSERT INTO [dbo].[CompanyRelationships] ([CompanyRelationshipId], [CompanyRelationshipTypeId], [FromCompany], [ToCompany]) VALUES (1, 1, 1008, 3012)
INSERT INTO [dbo].[CompanyRelationships] ([CompanyRelationshipId], [CompanyRelationshipTypeId], [FromCompany], [ToCompany]) VALUES (2, 1, 8, 3012)
INSERT INTO [dbo].[CompanyRelationships] ([CompanyRelationshipId], [CompanyRelationshipTypeId], [FromCompany], [ToCompany]) VALUES (3, 1, 3014, 3015)
INSERT INTO [dbo].[CompanyRelationships] ([CompanyRelationshipId], [CompanyRelationshipTypeId], [FromCompany], [ToCompany]) VALUES (4, 1, 3013, 3015)
INSERT INTO [dbo].[CompanyRelationships] ([CompanyRelationshipId], [CompanyRelationshipTypeId], [FromCompany], [ToCompany]) VALUES (5, 2, 3016, 1010)
INSERT INTO [dbo].[CompanyRelationships] ([CompanyRelationshipId], [CompanyRelationshipTypeId], [FromCompany], [ToCompany]) VALUES (6, 2, 3017, 3018)
SET IDENTITY_INSERT [dbo].[CompanyRelationships] OFF
