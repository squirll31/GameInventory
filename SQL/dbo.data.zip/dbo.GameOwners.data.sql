SET IDENTITY_INSERT [dbo].[GameOwners] ON
INSERT INTO [dbo].[GameOwners] ([GameOwnerId], [GameOwnerName], [OwnerUserId]) VALUES (1, N'Matthew', NULL)
INSERT INTO [dbo].[GameOwners] ([GameOwnerId], [GameOwnerName], [OwnerUserId]) VALUES (2, N'Andrew', NULL)
INSERT INTO [dbo].[GameOwners] ([GameOwnerId], [GameOwnerName], [OwnerUserId]) VALUES (3, N'Leah', NULL)
INSERT INTO [dbo].[GameOwners] ([GameOwnerId], [GameOwnerName], [OwnerUserId]) VALUES (4, N'Megan', NULL)
SET IDENTITY_INSERT [dbo].[GameOwners] OFF
