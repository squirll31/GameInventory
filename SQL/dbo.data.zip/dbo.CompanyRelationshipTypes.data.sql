SET IDENTITY_INSERT [dbo].[CompanyRelationshipTypes] ON
INSERT INTO [dbo].[CompanyRelationshipTypes] ([CompanyRelationshipTypeId], [CompanyRelationshipTypeName]) VALUES (1, N'Merger')
INSERT INTO [dbo].[CompanyRelationshipTypes] ([CompanyRelationshipTypeId], [CompanyRelationshipTypeName]) VALUES (2, N'Renaming')
SET IDENTITY_INSERT [dbo].[CompanyRelationshipTypes] OFF
